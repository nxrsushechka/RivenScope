# RivenScope — итог этапов, 2026-11-10

Status keys: DONE = implemented and checked; BLOCKED = upstream capability absent;
IN PROGRESS = active work; PENDING = not yet verified. No blocked feature counts as done.

| Phase | Tasks | Status |
|---|---|---|
| 1 API feasibility | Official docs, rules, ToS, live manifest evidence, capability matrix | DONE; contract access BLOCKED |
| 2 Architecture | Stack comparison, module boundaries, SQLite schema, limitations | DONE |
| 3 Foundation | Package, Qt GUI, XDG storage, logging, migrations | DONE; initial launch and SQLite checks passed |
| 4 Integration | Public v2 catalog, async transport, fair scheduler, retry/cache | DONE для справочников, включая установленный native Wayland release; contracts BLOCKED |
| 5 Monitoring & filters | Capability-aware controls, watchlists, nested visual filters, discovery | Local engines and visual preset checks DONE; live contracts BLOCKED |
| 6 Valuation | Robust comparable estimator, risk, insufficient-data behavior | Controlled statistical tests DONE; real market validation BLOCKED |
| 7 Analytics | Local observation charts and price distributions | DONE для локальных данных; реальные contract observations BLOCKED |
| 8 Notifications & trading | Persistent deduplication, channels, explicit user actions | DONE для каналов/suppression; реальная доставка и аудиопайплайн проверены; live deals / official message BLOCKED |
| 9 Advanced UI | Virtual tables, saved layout, settings, data tools | DONE; native visual inspection, resize и 100k-row checks passed |
| 10 QA | Unit/integration/UI/live/packaging/soak checks and defect fixes | DONE в доступном объёме: 53 tests, 10-min controlled soak; реальные contract tests BLOCKED |
| 11 Installation | Release artifact, per-user launcher/icon, installed launch, manuals | DONE; terminal/menu native Wayland launch and clean shutdown confirmed |

## Phase 1 report
- Omarchy 4.0.6, Hyprland/Wayland, Python 3.14.8, PySide6/Qt 6.12 already installed.
- Official v2 docs describe Riven weapon and attribute manifests, not contract search.
- v1 explicitly deprecated and unsupported. New-orders WebSocket is not a contract feed.
- Probing only documented public routes with an explicit RivenScope User-Agent.
- Four HTTP 200 responses recorded: versions, 420 weapons, 50 attributes, Torid.
- ToS returned HTTP 200; embedded official terms inspected; stricter contract limit 10/min.
- `docs/API_FEASIBILITY.md` completed before application development.

## Phase 2 report
- Selected installed native Python/PySide6 + asynchronous QtNetwork + SQLite.
- `docs/ARCHITECTURE.md` compares alternatives and defines thread, source and storage boundaries.
- Source-dependent features stay BLOCKED; local functionality will be implemented and tested explicitly.

## Phases 3–6 report
- 31 initial parsing, SQLite, migration, backup, discovery, filtering, pricing and scheduler tests passed.
- Real fixtures exposed parentheses/slashes in WFM slugs; corrected parsing to accept the verified source.
- Initial GUI construction defect found by offscreen launch and fixed; startup exceptions now stop worker safely.
- Controlled Qt integration verifies reconnection, Retry-After, 25 repeated start/stop cycles, persistent cache and corrupted-database recovery.
- Pricing uses same context/signature comparables, outlier rejection and asking-price uncertainty; no populated production contract table.

## Phases 7–9 report
- Six English UI sections, catalog details, virtual market table, visual AST editor, presets and settings are implemented.
- SQLite analytics separates fixed-price snapshots and bids; empty history is explicitly labelled.
- 100,000-row table test caught slow cross-language comparator sorting; switched to one key evaluation per row and verified the regression test passes.
- Native live/catalog, desktop notification delivery and completed audio playback pipeline passed.
- Локальная цепочка observation → valuation → alert проверяется отдельно от API. Для каждого
  пресета valuation пересчитывается с его собственным максимальным возрастом данных.

## Phases 10–11 report
- Полный прогон: **53 passed, 0 failed, 0 skipped**; журнал `test-artifacts/test-suite.log`.
- Controlled soak 600 с: 2 399 обновлений, 0 ошибок, RSS после прогрева +1,09 МБ,
  UI heartbeat p99 26,7 мс, штатное завершение worker.
- Повторная сборка одинаковых исходников даёт идентичные SHA256 wheel/source archive.
- Проверены staged install, обновление, запуск в пути с пробелами и удаление с сохранением данных.
- Реальная установка: `~/.local/bin/rivenscope`, desktop entry, SVG icon, immutable versioned releases.
- `gtk-launch rivenscope` открыл установленный Python/Qt release: `xwayland=false`.
- Закрытие адресованного окна завершило процесс. Пользовательская SQLite: integrity `ok`,
  420 weapons, 50 attributes, 0 contracts. Исходники Python совпадают с установленными.
- Полный архив и локальная установка доступны; GitHub publication/remote update source отсутствуют.

## Definition of Done — оговорка
Доступные локальные функции и установка завершены. **Исходная полная Definition of Done
не выполнена:** ключевые live-market сценарии заблокированы отсутствием подтверждённого
поддерживаемого публичного contract API. Это не засчитывается как реализованный мониторинг.
Следующий существенный этап — официально поддерживаемый contract adapter и его реальные тесты.
